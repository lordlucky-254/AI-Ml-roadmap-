# Project Ladder

Projects turn study into evidence that you can formulate a question, work with data, build a baseline, evaluate it honestly, and communicate limitations. Complete a small project at each level before starting a large capstone.

**Data note:** These are project shapes, not endorsements of any particular dataset. Find data through sources such as [UCI](https://archive.ics.uci.edu/), [OpenML](https://www.openml.org/), or [Hugging Face Datasets](https://huggingface.co/datasets), and verify the dataset's documentation, license, permitted use, privacy implications, and quality before downloading. Never commit restricted or private data.

## Beginner — learn the workflow

### 1. Data story without a model

Choose a small public dataset. Ask one descriptive question, clean the data, make a few well-labeled plots, and write what the data can and cannot support. This teaches data quality and communication before modeling.

**Show:** source/license, data dictionary, cleaning steps, plots, missingness, and a one-page conclusion.

### 2. Simple tabular prediction

Choose a regression or classification task with a clearly defined target. Compare a naive baseline with a linear model or small tree. Make a reasonable train/test split and calculate relevant metrics.

**Show:** target definition, baseline, split rationale, pipeline, metric explanation, and a few errors.

### 3. Text classification baseline

Classify a permissioned set of short texts, for example by topic or sentiment. Start with a simple bag-of-words or TF-IDF model before a pretrained transformer.

**Show:** label quality concerns, train/validation/test split, class-level metrics, example errors, and careful handling of user-generated text.

## Intermediate — improve reliability

### 4. Imbalanced classification

Use a suitable open dataset or a synthetic problem where the positive class is uncommon. Compare a simple baseline and a stronger model; discuss thresholds, precision/recall trade-offs, and the cost of false alerts. Do not present it as a real screening or decision tool.

### 5. Image transfer learning

Use a small image dataset with a license that permits the project. Fine-tune a pretrained model, compare with a simple baseline if practical, and inspect mistakes by class, lighting, background, or other relevant condition.

### 6. Time-series forecast

Forecast a future quantity using a chronological split and rolling-origin validation. Compare against a naive and seasonal-naive forecast before trying a more complex model.

### 7. Recommendation or ranking

Create a small recommender from public, permitted interactions or a synthetic dataset. Compare top-k results to a popularity baseline and discuss cold-start and offline-evaluation limitations.

## Advanced — systems, generative AI, or research

### 8. Evidence-grounded RAG prototype

Build a small retrieval-augmented question-answering system over public documents. Measure retrieval and answer support separately; include unanswerable questions, stale or conflicting sources, and prompt-injection tests. Link sources and explain that citations do not guarantee correctness.

### 9. Reproducible prediction service

Package a completed model behind a batch interface or small API. Add schema checks, tests, version tracking, safe logging, monitoring ideas, and rollback instructions. A local demo is enough; do not deploy without reviewing privacy, security, and use risks.

### 10. Paper reproduction or ablation

Choose a paper with accessible code and data. Reproduce a baseline and one central result, or test one carefully scoped ablation. Record deviations, compute limits, failed runs, and uncertainty. Do not claim exact reproduction when key details differ.

## Quality checklist for every project

- [ ] The question, intended use, and prediction time are clear.
- [ ] Data source, license, permissions, and limitations are documented.
- [ ] A simple baseline is reported.
- [ ] Train/validation/test or other evaluation design matches the intended use.
- [ ] Preprocessing is fit only where allowed; leakage risks are discussed.
- [ ] Metrics are chosen before comparing models and explained in plain language.
- [ ] Errors, uncertainty, and relevant group/context differences are inspected.
- [ ] Privacy, safety, security, and possible misuse are considered.
- [ ] A fresh reader can reproduce the result using the README.
- [ ] The conclusion does not claim more than the evidence supports.

Use [`PROJECT_TEMPLATE.md`](PROJECT_TEMPLATE.md) for a report structure. A clean, modest project with honest evaluation is stronger than a large project with an unsupported accuracy claim.
